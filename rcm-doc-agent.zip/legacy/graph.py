r"""LangGraph engine (ACTIVE).

The agent's reason -> plan -> act -> observe -> respond loop is implemented as a
LangGraph `StateGraph`. Nodes are pure-ish functions over a shared `AgentState`;
conditional edges form the loop and the terminal branches.

    START -> decide --(route on action / budget)--> clarify
                    \                              -> execute --> (loop back to decide)
                     \                             -> finalize --> END
                      -> give_up --> END

Same public surface as the previous custom loop:
`LangGraphAgent(settings, llm, df, clarify_handler).run(question, history_recap,
on_event, on_token) -> AgentOutcome`, so every existing call site is unchanged.

Design notes:
- We keep the JSON `AgentStep` control contract and the deterministic mock, so
  the graph runs offline and across providers exactly as before.
- Human-in-the-loop clarification is handled inside the `clarify` node via the
  injected handler (mirroring the CLI/eval behaviour). LangGraph's native
  `interrupt()` + a checkpointer is the idiomatic alternative and is noted in
  the README; we keep the handler approach so the non-interactive eval path is
  identical to the original.
- Budgets (max_steps, max_code_retries) are enforced in the routers; the graph
  is also compiled/invoked with a `recursion_limit` as a hard backstop.
"""

from __future__ import annotations

from typing import Optional, TypedDict

import pandas as pd
from langgraph.graph import END, START, StateGraph
from pydantic import ValidationError

from .common_csv import AgentOutcome, ClarifyHandler
from src.common import _extract_json
from src.config import Settings
from src.llm import LLMClient, LLMError
from src.logging_utils import RunTrace
from .profiling import profile_dataframe, render_profile
from .prompts import (
    FEWSHOT,
    SYSTEM_PROMPT,
    build_observation_message,
    build_task_message,
)
from .schemas import Action, AgentStep, FinalAnswer
from .tools import run_python


class AgentState(TypedDict, total=False):
    question: str
    history_recap: Optional[str]
    messages: list
    step: int
    code_retries: int
    decision: AgentStep
    outcome: AgentOutcome


class LangGraphAgent:
    def __init__(self, settings: Settings, llm: LLMClient, df: pd.DataFrame,
                 clarify_handler: ClarifyHandler | None = None):
        self.s = settings
        self.llm = llm
        self.df = df
        self.clarify_handler = clarify_handler
        self.profile_text = render_profile(profile_dataframe(df))
        self._app = self._build_graph()
        # Per-run scratch (single-threaded per instance).
        self._trace: RunTrace | None = None
        self._on_event = None
        self._on_token = None

    # -- graph construction ------------------------------------------------
    def _build_graph(self):
        g = StateGraph(AgentState)
        g.add_node("decide", self._decide_node)
        g.add_node("execute", self._execute_node)
        g.add_node("clarify", self._clarify_node)
        g.add_node("finalize", self._finalize_node)
        g.add_node("give_up", self._give_up_node)

        g.add_edge(START, "decide")
        g.add_conditional_edges("decide", self._route_after_decide, {
            "clarify": "clarify", "execute": "execute", "finalize": "finalize",
            "give_up": "give_up", "end": END,
        })
        g.add_conditional_edges("execute", self._route_loop, {"decide": "decide", "end": END})
        g.add_conditional_edges("clarify", self._route_loop, {"decide": "decide", "end": END})
        g.add_conditional_edges("finalize", self._route_loop, {"decide": "decide", "end": END})
        g.add_edge("give_up", END)
        return g.compile()

    # -- public API --------------------------------------------------------
    def run(self, question: str, history_recap: str | None = None,
            on_event=None, on_token=None) -> AgentOutcome:
        self._trace = RunTrace(self.s.log_dir, question)
        self._on_event, self._on_token = on_event, on_token

        init: AgentState = {
            "question": question,
            "history_recap": history_recap,
            "messages": [
                *FEWSHOT,
                {"role": "user",
                 "content": build_task_message(self.profile_text, question, history_recap)},
            ],
            "step": 0,
            "code_retries": 0,
        }
        # recursion_limit: each turn is ~2 supersteps; add headroom as a backstop.
        final_state = self._app.invoke(
            init, config={"recursion_limit": self.s.max_steps * 4 + 10}
        )
        outcome = final_state.get("outcome")
        if outcome is None:  # should not happen, but stay graceful
            outcome = AgentOutcome(status="error", steps_used=final_state.get("step", 0),
                                   trace_path=self._trace.path,
                                   message="graph ended without an outcome")
        return outcome

    # -- shared emit -------------------------------------------------------
    def _emit(self, step: int, kind: str, **fields):
        self._trace.record(step, kind, **fields)
        if self._on_event:
            self._on_event({"step": step, "kind": kind, **fields})

    # -- nodes -------------------------------------------------------------
    def _decide_node(self, state: AgentState) -> dict:
        step = state["step"] + 1
        messages = list(state["messages"])
        try:
            decision = self._decide(messages, step)
        except LLMError as exc:
            self._emit(step, "error", message=f"LLM failure: {exc}")
            return {"step": step,
                    "outcome": AgentOutcome(status="error", steps_used=step,
                                            trace_path=self._trace.path,
                                            message=f"LLM unavailable: {exc}")}
        messages.append({"role": "assistant", "content": decision.model_dump_json()})
        self._emit(step, "decision", action=decision.action.value,
                   thought=decision.thought, code=decision.code)
        return {"step": step, "decision": decision, "messages": messages}

    def _execute_node(self, state: AgentState) -> dict:
        step = state["step"]
        decision = state["decision"]
        messages = list(state["messages"])
        result = run_python(decision.code or "", self.df, self.s.sandbox_timeout)
        self._emit(step, "observation", ok=result.ok, result_repr=result.result_repr,
                   error=result.error, duration_s=result.duration_s)
        messages.append({"role": "user", "content": build_observation_message(result)})

        code_retries = state["code_retries"]
        if not result.ok:
            code_retries += 1
            if code_retries > self.s.max_code_retries:
                return {"messages": messages, "code_retries": code_retries,
                        "outcome": self._give_up(step, "exceeded code-retry budget")}
        return {"messages": messages, "code_retries": code_retries}

    def _clarify_node(self, state: AgentState) -> dict:
        step = state["step"]
        decision = state["decision"]
        if self.clarify_handler is None:
            return {"outcome": AgentOutcome(status="clarify", questions=decision.questions,
                                            steps_used=step, trace_path=self._trace.path)}
        messages = list(state["messages"])
        answer = self.clarify_handler(decision.questions)
        messages.append({"role": "user", "content": f"CLARIFICATION: {answer}"})
        return {"messages": messages}

    def _finalize_node(self, state: AgentState) -> dict:
        step = state["step"]
        decision = state["decision"]
        if decision.final_answer is None:
            messages = list(state["messages"])
            messages.append({"role": "user",
                             "content": "FINALIZE requires a non-null final_answer. "
                                        "Re-emit with the final_answer object."})
            return {"messages": messages}  # loop back to decide
        self._emit(step, "final", summary=decision.final_answer.summary)
        return {"outcome": AgentOutcome(status="ok", final_answer=decision.final_answer,
                                        steps_used=step, trace_path=self._trace.path)}

    def _give_up_node(self, state: AgentState) -> dict:
        step = state["step"]
        return {"outcome": self._give_up(step, "reached max steps")}

    # -- routers -----------------------------------------------------------
    def _route_after_decide(self, state: AgentState) -> str:
        if state.get("outcome"):
            return "end"
        decision = state["decision"]
        if state["step"] >= self.s.max_steps and decision.action != Action.FINALIZE:
            return "give_up"
        return decision.action.value  # "clarify" | "execute" | "finalize"

    @staticmethod
    def _route_loop(state: AgentState) -> str:
        return "end" if state.get("outcome") else "decide"

    # -- helpers (identical semantics to the original loop) ----------------
    def _decide(self, messages: list[dict], step: int) -> AgentStep:
        """Get one validated AgentStep, self-correcting invalid JSON up to 2x."""
        parse_retries = 2
        for _ in range(parse_retries + 1):
            raw = self.llm.complete(SYSTEM_PROMPT, messages, on_token=self._on_token)
            try:
                return AgentStep.model_validate_json(_extract_json(raw))
            except (ValidationError, ValueError) as exc:
                self._emit(step, "parse_error", message=str(exc)[:300])
                messages.append({"role": "assistant", "content": raw})
                messages.append({"role": "user",
                                 "content": f"Your previous message was not a valid AgentStep "
                                            f"JSON object ({str(exc)[:200]}). Re-emit ONLY the "
                                            f"JSON, no prose, no code fences."})
        raise LLMError("could not obtain valid AgentStep JSON after retries")

    def _give_up(self, step: int, why: str) -> AgentOutcome:
        fa = FinalAnswer(
            summary=f"Unable to complete the analysis ({why}).",
            findings=[],
            caveats=["The agent hit a guard-rail budget before finishing."],
        )
        self._emit(step, "final", summary=fa.summary)
        return AgentOutcome(status="incomplete", final_answer=fa,
                            steps_used=step, trace_path=self._trace.path, message=why)
