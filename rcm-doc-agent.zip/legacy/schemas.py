"""Structured-output contracts.

The agent's control protocol is a single Pydantic model, `AgentStep`, that the
LLM must emit as JSON on every turn. Validating each turn against this schema
is how we get reliable, machine-dispatchable decisions out of a text model.
"""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class Action(str, Enum):
    """The three things the agent can decide to do on any turn."""

    CLARIFY = "clarify"      # question is ambiguous -> ask the user
    EXECUTE = "execute"      # run pandas code against the dataframe (tool call)
    FINALIZE = "finalize"    # enough evidence gathered -> answer


class Finding(BaseModel):
    insight: str = Field(..., description="A single, specific claim about the data.")
    evidence: str = Field(
        ..., description="The concrete number / value from an executed cell that supports it."
    )


class FinalAnswer(BaseModel):
    summary: str = Field(..., description="1-3 sentence direct answer to the user's question.")
    findings: list[Finding] = Field(default_factory=list)
    caveats: list[str] = Field(
        default_factory=list,
        description="Assumptions or limitations (e.g. small sample, nulls dropped).",
    )


class AgentStep(BaseModel):
    """One reasoning turn. `thought` is the chain-of-thought; `action` routes it."""

    thought: str = Field(..., description="Brief reasoning for this decision.")
    action: Action

    # action == CLARIFY
    questions: list[str] = Field(default_factory=list)

    # action == EXECUTE
    code: str | None = Field(
        default=None,
        description="Self-contained pandas snippet. `df`, `pd`, `np` are in scope. "
        "Assign the value you care about to a variable named `result`.",
    )

    # action == FINALIZE
    final_answer: FinalAnswer | None = None


class ExecutionResult(BaseModel):
    """Return value of the code-execution tool (the agent's `observe` input)."""

    ok: bool
    stdout: str = ""
    result_repr: str = ""     # repr() of the `result` variable, if the code set one
    error: str | None = None  # exception text or guard-rail rejection reason
    duration_s: float = 0.0


# --------------------------------------------------------------------------- #
# Multi-agent orchestration
# --------------------------------------------------------------------------- #
class Plan(BaseModel):
    """Planner output: a complex question decomposed into standalone subtasks."""

    reasoning: str = Field(..., description="Why the question was split this way.")
    subtasks: list[str] = Field(
        ..., description="Self-contained analytical questions a specialist can answer alone."
    )


class SubtaskResult(BaseModel):
    subtask: str
    answer: FinalAnswer | None = None
    status: str = "ok"


class OrchestrationOutcome(BaseModel):
    """Full result of a planner -> specialists -> synthesizer run."""

    plan: Plan
    subtask_results: list[SubtaskResult]
    final_answer: FinalAnswer
    steps_used: int = 0
