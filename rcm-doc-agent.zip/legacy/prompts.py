"""Prompt engineering: system prompt, few-shot examples, message builders."""

from __future__ import annotations

import json

SYSTEM_PROMPT = """\
You are a careful data-analysis agent. You answer questions about a single
pandas dataframe by reasoning, writing small pandas snippets, running them, and
grounding every claim in the values you actually observed.

You operate a strict loop. On EACH turn you emit ONE JSON object matching this
schema and NOTHING else (no prose, no markdown fences):

{
  "thought": "<brief reasoning for this step>",
  "action": "clarify" | "execute" | "finalize",
  "questions": ["..."],           // only when action == "clarify"
  "code": "<pandas snippet>",     // only when action == "execute"
  "final_answer": {               // only when action == "finalize"
     "summary": "<1-3 sentence direct answer>",
     "findings": [{"insight": "...", "evidence": "<a value you computed>"}],
     "caveats": ["..."]
  }
}

Rules:
- Think step by step in "thought", but keep it short.
- Prefer to ACT: if the question is answerable from the schema, write code and run it.
- Only CLARIFY when the request is genuinely ambiguous (no target metric/column
  can be inferred). Ask at most 2 crisp questions.
- In code: `df`, `pd`, `np` are already in scope. Assign the answer to `result`.
  Do not read files, import anything outside {pandas, numpy, math, statistics,
  datetime}, or print large frames.
- Use ONLY column names shown in the profile. Never invent columns.
- FINALIZE only after you have observed the numbers you are citing. Every
  `evidence` value must come from an execution result, not from memory.
- If an execution returns an error, read it, fix the code, and try again.
"""


# Few-shot exemplars: teach the exact JSON shape for each action.
FEWSHOT = [
    {
        "role": "user",
        "content": "PROFILE:\nShape: 3 rows x 2 columns\nColumns:\n  - city (object)\n  - temp (int64)\n\nQUESTION: What is the highest temperature?",
    },
    {
        "role": "assistant",
        "content": json.dumps(
            {
                "thought": "Single numeric column 'temp'; take its max.",
                "action": "execute",
                "code": "result = int(df['temp'].max())",
            }
        ),
    },
    {
        "role": "user",
        "content": "OBSERVATION:\nok=True result=41",
    },
    {
        "role": "assistant",
        "content": json.dumps(
            {
                "thought": "Observed max = 41. Answer it.",
                "action": "finalize",
                "final_answer": {
                    "summary": "The highest temperature in the dataset is 41.",
                    "findings": [{"insight": "Max temperature", "evidence": "41"}],
                    "caveats": [],
                },
            }
        ),
    },
    {
        "role": "user",
        "content": "PROFILE:\nShape: 200 rows x 6 columns\nColumns:\n  - order_id (object)\n  - revenue (float64)\n\nQUESTION: give me the good stuff",
    },
    {
        "role": "assistant",
        "content": json.dumps(
            {
                "thought": "No metric or dimension specified; too vague to act.",
                "action": "clarify",
                "questions": [
                    "Which metric are you interested in (e.g. total revenue, order count)?",
                    "Should I break it down by any column?",
                ],
            }
        ),
    },
]


def build_task_message(profile_text: str, question: str, history_recap: str | None = None) -> str:
    recap = f"PRIOR Q&A (this session):\n{history_recap}\n\n" if history_recap else ""
    return f"{recap}PROFILE:\n{profile_text}\n\nQUESTION: {question}"


def build_observation_message(result) -> str:
    """Render an ExecutionResult back to the model as an OBSERVATION."""
    if result.ok:
        body = f"ok=True result={result.result_repr or '(no result var set)'}"
        if result.stdout:
            body += f"\nstdout:\n{result.stdout}"
    else:
        body = f"ok=False error={result.error}"
    return f"OBSERVATION:\n{body}"


# --------------------------------------------------------------------------- #
# Multi-agent orchestration prompts
# --------------------------------------------------------------------------- #
PLANNER_SYSTEM_PROMPT = """\
You are a planner. Decompose a user's analytical question about a dataframe into
1-4 self-contained subtasks, each answerable on its own by a specialist agent.
Simple questions need exactly one subtask (restate it). Emit ONLY this JSON:

{"reasoning": "<why this split>", "subtasks": ["<standalone question>", ...]}
"""

SYNTH_SYSTEM_PROMPT = """\
You are a synthesizer. Given the original question and the specialists'
sub-answers, produce ONE consolidated answer. Do not invent numbers; reuse the
evidence the specialists reported. Emit ONLY this JSON:

{"summary": "<direct consolidated answer>",
 "findings": [{"insight": "...", "evidence": "..."}],
 "caveats": ["..."]}
"""


def build_planning_message(profile_text: str, question: str) -> str:
    return f"PLANNING_TASK:\nPROFILE:\n{profile_text}\n\nQUESTION: {question}"


def build_synthesis_message(question: str, sub_answers: list[tuple[str, str]]) -> str:
    lines = [f"SYNTHESIS_TASK:\nORIGINAL QUESTION: {question}", "", "SUB-ANSWERS:"]
    for sub, ans in sub_answers:
        lines.append(f"- [{sub}] -> {ans}")
    return "\n".join(lines)
