"""Tool registry.

The agent has exactly one external tool: `run_python`, backed by the sandbox.
Exposing it with an explicit JSON schema keeps the contract clear and makes it
trivial to swap in provider-native tool-calling later. The agent invokes it via
the `EXECUTE` action rather than provider tool-calling so the same control loop
works identically across the anthropic / openai / mock backends.
"""

from __future__ import annotations

import pandas as pd

from .sandbox import run_code
from .schemas import ExecutionResult

RUN_PYTHON_SCHEMA = {
    "name": "run_python",
    "description": (
        "Execute a self-contained pandas snippet against the loaded dataframe. "
        "`df`, `pd`, and `np` are in scope. Assign the value of interest to a "
        "variable named `result`. Disallowed: file/network/os access, imports "
        "outside {pandas, numpy, math, statistics, datetime}."
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "code": {"type": "string", "description": "The pandas snippet to run."}
        },
        "required": ["code"],
    },
}


def run_python(code: str, df: pd.DataFrame, timeout: float) -> ExecutionResult:
    """Thin dispatch wrapper so the loop depends on `tools`, not `sandbox` directly."""
    return run_code(code, df, timeout=timeout)
