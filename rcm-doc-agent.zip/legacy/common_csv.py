"""CSV-agent-only shared types (split out of src/common.py).

`AgentOutcome` and `ClarifyHandler` depend on `FinalAnswer`, which is a
CSV-agent schema (`legacy/schemas.py`). The generic `_extract_json` helper
that both the CSV agent and the document-extraction agent use stays in
`src/common.py`; only the CSV-specific types live here.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

from .schemas import FinalAnswer

ClarifyHandler = Callable[[list[str]], str]


@dataclass
class AgentOutcome:
    status: str  # "ok" | "clarify" | "incomplete" | "error"
    final_answer: FinalAnswer | None = None
    questions: list[str] = field(default_factory=list)
    steps_used: int = 0
    trace_path: str | None = None
    message: str | None = None
