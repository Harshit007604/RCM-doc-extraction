"""Deterministic dataframe profiling.

Profiling runs once up front (not via the LLM) and its compact text rendering
is injected into the prompt. Giving the model an accurate schema + stats up
front is the single biggest lever for reducing hallucinated column names.
"""

from __future__ import annotations

import pandas as pd


def profile_dataframe(df: pd.DataFrame, sample_rows: int = 3) -> dict:
    """Return a JSON-serializable profile of the dataframe."""
    numeric = df.select_dtypes("number")
    return {
        "n_rows": int(len(df)),
        "n_cols": int(df.shape[1]),
        "columns": [
            {
                "name": str(c),
                "dtype": str(df[c].dtype),
                "nulls": int(df[c].isna().sum()),
                "n_unique": int(df[c].nunique(dropna=True)),
            }
            for c in df.columns
        ],
        "numeric_describe": {
            col: {k: _round(v) for k, v in numeric[col].describe().to_dict().items()}
            for col in numeric.columns
        },
        "sample": df.head(sample_rows).to_dict(orient="records"),
    }


def _round(v):
    try:
        return round(float(v), 4)
    except (TypeError, ValueError):
        return v


def render_profile(profile: dict) -> str:
    """Render the profile as a compact, prompt-friendly text block."""
    lines = [f"Shape: {profile['n_rows']} rows x {profile['n_cols']} columns", "", "Columns:"]
    for c in profile["columns"]:
        lines.append(
            f"  - {c['name']} ({c['dtype']}) "
            f"| nulls={c['nulls']} | unique={c['n_unique']}"
        )
    if profile["numeric_describe"]:
        lines.append("")
        lines.append("Numeric summary (mean / min / max):")
        for col, stats in profile["numeric_describe"].items():
            lines.append(
                f"  - {col}: mean={stats.get('mean')} "
                f"min={stats.get('min')} max={stats.get('max')}"
            )
    lines.append("")
    lines.append("Sample rows:")
    for row in profile["sample"]:
        lines.append(f"  {row}")
    return "\n".join(lines)
