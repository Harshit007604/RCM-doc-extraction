"""Child-process entrypoint for sandboxed code execution.

Invoked by `sandbox.run_code` as a *separate* process so that a hard wall-clock
timeout (process kill) and OS-level isolation are possible. It reads a pickled
dataframe and a code file, execs the code in a restricted namespace, and prints
a single JSON object to stdout describing the outcome.

This file is intentionally dependency-light and never imported by the agent.
"""

from __future__ import annotations

import argparse
import contextlib
import io
import json
import pickle
import sys


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="path to pickled dataframe")
    ap.add_argument("--code", required=True, help="path to code file")
    args = ap.parse_args()

    with open(args.data, "rb") as fh:
        df = pickle.load(fh)
    with open(args.code, "r", encoding="utf-8") as fh:
        code = fh.read()

    import numpy as np
    import pandas as pd

    # Minimal, explicit namespace. No access to os/sys/open/etc.
    safe_builtins = {
        "len": len, "range": range, "min": min, "max": max, "sum": sum,
        "sorted": sorted, "round": round, "abs": abs, "list": list,
        "dict": dict, "set": set, "tuple": tuple, "float": float, "int": int,
        "str": str, "bool": bool, "enumerate": enumerate, "zip": zip,
        "map": map, "filter": filter, "print": print,
    }
    namespace = {
        "__builtins__": safe_builtins,
        "df": df, "pd": pd, "np": np,
    }

    buf = io.StringIO()
    payload = {"ok": False, "stdout": "", "result_repr": "", "error": None}
    try:
        with contextlib.redirect_stdout(buf):
            exec(code, namespace)  # noqa: S102 - guarded upstream + isolated process
        payload["ok"] = True
        if "result" in namespace:
            payload["result_repr"] = repr(namespace["result"])[:4000]
    except Exception as exc:  # noqa: BLE001 - report any failure to the parent
        payload["error"] = f"{type(exc).__name__}: {exc}"
    finally:
        payload["stdout"] = buf.getvalue()[:4000]

    sys.stdout.write(json.dumps(payload))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
