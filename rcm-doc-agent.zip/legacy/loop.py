"""Agent loop — shared types + façade over the active engine.

This is the legacy CSV data-analysis agent, moved out of `src/` to keep the
active codebase focused on document extraction (see `src/docproc/`). It still
runs standalone: `python legacy/agent_csv.py --query "..."`.

The ACTIVE agent engine (for this CSV agent) is a LangGraph `StateGraph` in
`legacy/graph.py`. For backward compatibility every caller still does
`from legacy.loop import AgentLoop`; at the bottom of this module that name is
re-exported from the graph implementation, so no call site needed to change.

The original hand-rolled control loop (the pre-LangGraph implementation) is
PRESERVED BELOW as a commented reference block — it is intentionally not
deleted, so the two approaches can be compared side by side. The shared data
types (`AgentOutcome`, `ClarifyHandler`) live in `common_csv.py`, and the
generic `_extract_json` helper lives in `src/common.py` (shared with the
document-extraction agent).
"""

from __future__ import annotations

# Shared types/helpers now live in `common_csv` (CSV-specific) and `src.common`
# (generic, shared with the document-extraction agent). Re-exported here so
# existing call sites that do `from legacy.loop import AgentOutcome,
# ClarifyHandler, _extract_json` keep working unchanged.
from .common_csv import AgentOutcome, ClarifyHandler  # noqa: F401
from src.common import _extract_json  # noqa: F401


# ===========================================================================
# PRESERVED REFERENCE — original custom agent loop (pre-LangGraph).
# Superseded by src/graph.py. Kept (commented, not deleted) for comparison.
# It required these imports:
#   import pandas as pd
#   from pydantic import ValidationError
#   from .config import Settings
#   from .llm import LLMClient, LLMError
#   from .logging_utils import RunTrace
#   from .profiling import profile_dataframe, render_profile
#   from .prompts import FEWSHOT, SYSTEM_PROMPT, build_observation_message, build_task_message
#   from .schemas import Action, AgentStep
#   from .tools import run_python
#
# class AgentLoop:
#     def __init__(self, settings: Settings, llm: LLMClient, df: pd.DataFrame,
#                  clarify_handler: ClarifyHandler | None = None):
#         self.s = settings
#         self.llm = llm
#         self.df = df
#         self.clarify_handler = clarify_handler
#         self.profile = profile_dataframe(df)
#         self.profile_text = render_profile(self.profile)
#
#     def run(self, question: str, history_recap: str | None = None,
#             on_event=None, on_token=None) -> AgentOutcome:
#         trace = RunTrace(self.s.log_dir, question)
#
#         def emit(step: int, kind: str, **fields):
#             trace.record(step, kind, **fields)
#             if on_event:
#                 on_event({"step": step, "kind": kind, **fields})
#
#         messages: list[dict] = [
#             *FEWSHOT,
#             {"role": "user",
#              "content": build_task_message(self.profile_text, question, history_recap)},
#         ]
#         code_retries = 0
#
#         for step in range(1, self.s.max_steps + 1):
#             try:
#                 decision = self._decide(messages, emit, step, on_token=on_token)
#             except LLMError as exc:
#                 emit(step, "error", message=f"LLM failure: {exc}")
#                 return AgentOutcome(status="error", steps_used=step,
#                                     trace_path=trace.path,
#                                     message=f"LLM unavailable: {exc}")
#
#             messages.append({"role": "assistant", "content": decision.model_dump_json()})
#             emit(step, "decision", action=decision.action.value,
#                  thought=decision.thought, code=decision.code)
#
#             # -- dispatch ----------------------------------------------------
#             if decision.action == Action.CLARIFY:
#                 if self.clarify_handler is None:
#                     return AgentOutcome(status="clarify", questions=decision.questions,
#                                         steps_used=step, trace_path=trace.path)
#                 answer = self.clarify_handler(decision.questions)
#                 messages.append({"role": "user", "content": f"CLARIFICATION: {answer}"})
#                 continue
#
#             if decision.action == Action.EXECUTE:
#                 result = run_python(decision.code or "", self.df, self.s.sandbox_timeout)
#                 emit(step, "observation", ok=result.ok,
#                      result_repr=result.result_repr, error=result.error,
#                      duration_s=result.duration_s)
#                 messages.append({"role": "user",
#                                  "content": build_observation_message(result)})
#                 if not result.ok:
#                     code_retries += 1
#                     if code_retries > self.s.max_code_retries:
#                         return self._give_up(emit, step, "exceeded code-retry budget",
#                                              trace.path)
#                 continue
#
#             if decision.action == Action.FINALIZE:
#                 if decision.final_answer is None:
#                     messages.append({"role": "user",
#                                      "content": "FINALIZE requires a non-null final_answer. "
#                                                 "Re-emit with the final_answer object."})
#                     continue
#                 emit(step, "final", summary=decision.final_answer.summary)
#                 return AgentOutcome(status="ok", final_answer=decision.final_answer,
#                                     steps_used=step, trace_path=trace.path)
#
#         return self._give_up(emit, self.s.max_steps, "reached max steps", trace.path)
#
#     def _decide(self, messages: list[dict], emit, step: int, on_token=None) -> AgentStep:
#         """Get one validated AgentStep, self-correcting invalid JSON up to 2x."""
#         parse_retries = 2
#         for _ in range(parse_retries + 1):
#             raw = self.llm.complete(SYSTEM_PROMPT, messages, on_token=on_token)
#             try:
#                 return AgentStep.model_validate_json(_extract_json(raw))
#             except (ValidationError, ValueError) as exc:
#                 emit(step, "parse_error", message=str(exc)[:300])
#                 messages.append({"role": "assistant", "content": raw})
#                 messages.append({"role": "user",
#                                  "content": f"Your previous message was not a valid AgentStep "
#                                             f"JSON object ({str(exc)[:200]}). Re-emit ONLY the "
#                                             f"JSON, no prose, no code fences."})
#         raise LLMError("could not obtain valid AgentStep JSON after retries")
#
#     def _give_up(self, emit, step: int, why: str, trace_path: str | None = None) -> AgentOutcome:
#         fa = FinalAnswer(
#             summary=f"Unable to complete the analysis ({why}).",
#             findings=[],
#             caveats=["The agent hit a guard-rail budget before finishing."],
#         )
#         emit(step, "final", summary=fa.summary)
#         return AgentOutcome(status="incomplete", final_answer=fa,
#                             steps_used=step, trace_path=trace_path, message=why)
# ===========================================================================


# Active engine: LangGraph StateGraph. Re-exported as `AgentLoop` so existing
# imports (`from legacy.loop import AgentLoop`) transparently use the graph.
from .graph import LangGraphAgent as AgentLoop  # noqa: E402
