"""Lightweight evaluation harness.

Runs each scenario in `tests/scenarios.json` through the agent and scores the
outcome against expectations:

  - expected_action : the action the agent should take on a clarify-vs-answer
                      scenario ("clarify" or "finalize").
  - must_include    : case-insensitive substrings that must appear in the
                      rendered answer (summary + findings).
  - numeric         : {"value": float, "tolerance": float} checked against any
                      number found in the answer (quantitative check).

Requires a valid API key for the configured provider -- there is no offline
mode.

    python legacy/evaluate.py --scenarios legacy/tests/scenarios.json
    python legacy/evaluate.py --scenarios legacy/tests/scenarios.json --model openai/gpt-4.1
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys

# Allow both `python legacy/evaluate.py` and `python -m legacy.evaluate`.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd

from src.config import get_settings
from src.llm import LLMClient
from src.logging_utils import setup_logging
from legacy.loop import AgentLoop
from legacy.schemas import FinalAnswer


def _answer_text(fa: FinalAnswer | None) -> str:
    if fa is None:
        return ""
    parts = [fa.summary]
    parts += [f"{f.insight} {f.evidence}" for f in fa.findings]
    return " ".join(parts)


def _numbers(text: str) -> list[float]:
    return [float(x.replace(",", "")) for x in re.findall(r"-?\d[\d,]*\.?\d*", text)]


def score_scenario(scenario: dict, outcome) -> tuple[bool, list[str]]:
    checks: list[str] = []
    ok = True

    expected_action = scenario.get("expected_action")
    if expected_action == "clarify":
        passed = outcome.status == "clarify"
        checks.append(f"action==clarify: {'PASS' if passed else 'FAIL'} (got {outcome.status})")
        ok &= passed
        return ok, checks  # clarify scenarios stop here

    passed = outcome.status == "ok"
    checks.append(f"status==ok: {'PASS' if passed else 'FAIL'} (got {outcome.status})")
    ok &= passed

    text = _answer_text(outcome.final_answer).lower()
    for sub in scenario.get("must_include", []):
        hit = sub.lower() in text
        checks.append(f"includes '{sub}': {'PASS' if hit else 'FAIL'}")
        ok &= hit

    num = scenario.get("numeric")
    if num:
        found = _numbers(text)
        target, tol = float(num["value"]), float(num.get("tolerance", 0.01))
        hit = any(abs(f - target) <= tol for f in found)
        checks.append(f"numeric~={target}±{tol}: {'PASS' if hit else 'FAIL'} (found {found})")
        ok &= hit

    return ok, checks


def run(scenarios_path: str, csv_path: str, model: str | None) -> int:
    with open(scenarios_path, "r", encoding="utf-8") as fh:
        scenarios = json.load(fh)

    settings = get_settings(model=model)
    setup_logging("WARNING")  # keep eval output clean
    df = pd.read_csv(csv_path)
    llm = LLMClient(settings)

    total = len(scenarios)
    passed_count = 0
    print(f"\nRunning {total} scenarios with model='{settings.model}'\n" + "=" * 60)

    for i, scenario in enumerate(scenarios, 1):
        # In eval we never block on input: no clarify_handler => clarify surfaces.
        loop = AgentLoop(settings, llm, df, clarify_handler=None)
        outcome = loop.run(scenario["query"])
        ok, checks = score_scenario(scenario, outcome)
        passed_count += ok

        print(f"\n[{i}/{total}] {scenario['name']}  ->  {'✅ PASS' if ok else '❌ FAIL'}")
        print(f"      query: {scenario['query']}")
        for c in checks:
            print(f"      - {c}")
        if outcome.final_answer:
            print(f"      answer: {outcome.final_answer.summary}")

    print("\n" + "=" * 60)
    print(f"RESULT: {passed_count}/{total} scenarios passed "
          f"({100 * passed_count / total:.0f}%)")
    return 0 if passed_count == total else 1


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="Run agent evaluation scenarios.")
    p.add_argument("--scenarios", default="legacy/tests/scenarios.json")
    p.add_argument("--csv", default="legacy/data/sample_sales.csv")
    p.add_argument("--model", default=None, help="Override model (default: from env).")
    args = p.parse_args(argv)
    return run(args.scenarios, args.csv, args.model)


if __name__ == "__main__":
    raise SystemExit(main())
