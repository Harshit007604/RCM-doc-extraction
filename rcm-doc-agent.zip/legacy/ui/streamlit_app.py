"""Streamlit UI for the legacy CSV data-analysis agent.

Run:
    pip install streamlit
    streamlit run legacy/ui/streamlit_app.py

Features: provider/model controls, CSV upload, live step + token streaming,
optional multi-agent orchestration, and cross-session memory.
"""

from __future__ import annotations

import os
import sys

# Make `src` and `legacy` importable when launched via
# `streamlit run legacy/ui/streamlit_app.py`.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

import pandas as pd
import streamlit as st

from src.config import get_settings
from src.llm import LLMClient
from legacy.loop import AgentLoop
from legacy.memory import SessionStore
from legacy.orchestrator import Orchestrator

st.set_page_config(page_title="Data-Analysis Agent", page_icon="📊", layout="wide")
st.title("📊 Agentic CSV Data-Analysis Assistant")

# --- Sidebar: configuration ------------------------------------------------
with st.sidebar:
    st.header("Configuration")
    model = st.text_input("Model (LiteLLM string)", value="gemini/gemini-2.5-flash")
    temperature = st.slider("Temperature", 0.0, 1.0, 0.0, 0.1)
    multi_agent = st.toggle("Multi-agent (planner → specialists)", value=False)
    stream = st.toggle("Stream tokens/steps live", value=True)
    session_id = st.text_input("Session id (for memory)", value="ui-session")
    st.caption("Requires a valid API key set in `.env`, e.g. `GROQ_API_KEY` with "
               "model string `groq/llama-3.3-70b-versatile`.")

    uploaded = st.file_uploader("Upload a CSV (optional)", type=["csv"])

# --- Data ------------------------------------------------------------------
if uploaded is not None:
    df = pd.read_csv(uploaded)
    st.caption(f"Using uploaded CSV: {uploaded.name}")
else:
    default_csv = os.path.join(os.path.dirname(__file__), "..", "data", "sample_sales.csv")
    df = pd.read_csv(default_csv)
    st.caption("Using bundled sample: legacy/data/sample_sales.csv")

with st.expander("Preview data", expanded=False):
    st.dataframe(df.head(20), width="stretch")

# --- Query -----------------------------------------------------------------
question = st.text_input("Ask a question about the data",
                         value="Which region has the highest total revenue?")
run = st.button("Run analysis", type="primary")

if run and question.strip():
    settings = get_settings(model=model, temperature=temperature)
    llm = LLMClient(settings)

    store = SessionStore(settings.memory_dir)
    recap = SessionStore.recap(store.load(session_id)) if session_id else None

    log_lines: list[str] = []
    log_box = st.empty()
    token_box = st.empty()
    tokens: list[str] = []

    def on_event(ev: dict):
        kind = ev.get("kind")
        if kind == "plan":
            log_lines.append(f"🧭 **plan** — {len(ev['subtasks'])} subtasks")
        elif kind == "delegate":
            log_lines.append(f"➡️ **subtask {ev['index']}**: {ev['subtask']}")
        elif kind == "decision":
            log_lines.append(f"🧠 step {ev['step']} · `{ev['action']}` — {ev.get('thought','')}")
            if ev.get("code"):
                log_lines.append(f"```python\n{ev['code']}\n```")
        elif kind == "observation":
            tail = ev.get("result_repr") or ev.get("error") or ""
            log_lines.append(f"🔎 observation · ok={ev.get('ok')} · `{tail}`")
        elif kind == "final":
            log_lines.append(f"✅ **final** — {ev.get('summary','')}")
        log_box.markdown("\n\n".join(log_lines))

    def on_token(tok: str):
        tokens.append(tok)
        token_box.code("".join(tokens)[-600:], language="json")

    with st.status("Running agent…", expanded=True):
        if multi_agent:
            outcome = Orchestrator(settings, llm, df).run(question, on_event=on_event)
            final = outcome.final_answer
            steps = outcome.steps_used
            with st.expander("Plan & sub-answers", expanded=True):
                for i, r in enumerate(outcome.subtask_results, 1):
                    ans = r.answer.summary if r.answer else f"({r.status})"
                    st.markdown(f"**{i}. {r.subtask}** → {ans}")
        else:
            loop = AgentLoop(settings, llm, df, clarify_handler=None)
            res = loop.run(question, history_recap=recap,
                           on_event=on_event, on_token=on_token if stream else None)
            if res.status == "clarify":
                st.warning("Clarification needed:")
                for q in res.questions:
                    st.write(f"- {q}")
                st.stop()
            final = res.final_answer
            steps = res.steps_used

    st.subheader("Answer")
    st.success(final.summary)
    if final.findings:
        st.markdown("**Findings**")
        for f in final.findings:
            st.write(f"- {f.insight}: `{f.evidence}`")
    if final.caveats:
        st.markdown("**Caveats**")
        for c in final.caveats:
            st.write(f"- {c}")
    st.caption(f"Completed in {steps} steps.")

    if session_id:
        store.append(session_id, question, final.summary)
        st.caption(f"Saved to session '{session_id}'.")
