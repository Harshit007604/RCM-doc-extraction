"""CLI entrypoint for the legacy CSV data-analysis agent.

Moved out of `src/` to keep the active codebase focused on document
extraction (`src/docproc/`). Runs standalone:

    python legacy/agent_csv.py --query "Which region has the highest total revenue?"
    python legacy/agent_csv.py --query "..." --stream
    python legacy/agent_csv.py --query "..." --session alice
    python legacy/agent_csv.py --query "Give me an overview: total revenue, top region, \\
        and average revenue by category" --multi-agent
"""

from __future__ import annotations

import argparse
import os
import sys

# Allow both `python legacy/agent_csv.py` and `python -m legacy.agent_csv`.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd

from src.config import get_settings
from src.llm import LLMClient
from src.logging_utils import setup_logging
from legacy.loop import AgentLoop, AgentOutcome
from legacy.memory import SessionStore
from legacy.orchestrator import Orchestrator
from legacy.schemas import FinalAnswer, OrchestrationOutcome


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Agentic CSV data-analysis assistant (legacy).")
    p.add_argument("--query", default=None, help="Question about the CSV.")
    p.add_argument("--csv", default="legacy/data/sample_sales.csv", help="Path to the input CSV.")
    p.add_argument("--model", default=None,
                   help="LiteLLM model string, e.g. groq/llama-3.3-70b-versatile.")
    p.add_argument("--temperature", type=float, default=None, help="Override temperature.")
    p.add_argument("--non-interactive", action="store_true",
                   help="Do not prompt for clarifications; surface them and exit.")
    p.add_argument("--session", default=None,
                   help="Session id for cross-session memory (persists Q&A between runs).")
    p.add_argument("--multi-agent", action="store_true",
                   help="Use the planner -> specialists -> synthesizer orchestration.")
    p.add_argument("--stream", action="store_true",
                   help="Stream tokens and step events live to stderr.")
    return p.parse_args(argv)


def interactive_clarify(questions: list[str]) -> str:
    print("\n[The agent needs clarification]")
    for q in questions:
        print(f"  ? {q}")
    return input("Your answer: ").strip()


def make_stream_callbacks(enabled: bool):
    """Return (on_event, on_token) that render live progress to stderr."""
    if not enabled:
        return None, None

    def on_event(ev: dict):
        kind = ev.get("kind")
        if kind == "plan":
            print(f"\n[plan] {len(ev['subtasks'])} subtasks", file=sys.stderr)
        elif kind == "delegate":
            print(f"\n[delegate #{ev['index']}] {ev['subtask']}", file=sys.stderr)
        elif kind == "decision":
            print(f"\n[step {ev['step']}] {ev['action']}: {ev.get('thought','')}", file=sys.stderr)
        elif kind == "observation":
            tail = ev.get("result_repr") or ev.get("error") or ""
            print(f"[obs] ok={ev.get('ok')} {tail}", file=sys.stderr)
        elif kind == "final":
            print(f"[final] {ev.get('summary','')}", file=sys.stderr)

    def on_token(tok: str):
        print(tok, end="", file=sys.stderr, flush=True)

    return on_event, on_token


def render_outcome(outcome: AgentOutcome) -> str:
    if outcome.status == "clarify":
        lines = ["Clarification needed:"]
        lines += [f"  - {q}" for q in outcome.questions]
        return "\n".join(lines)
    return _render_answer(outcome.final_answer, outcome.status,
                          outcome.steps_used, outcome.trace_path, outcome.message)


def render_orchestration(outcome: OrchestrationOutcome) -> str:
    lines = [f"\n=== MULTI-AGENT PLAN ({len(outcome.plan.subtasks)} subtasks) ==="]
    for i, r in enumerate(outcome.subtask_results, 1):
        ans = r.answer.summary if r.answer else f"({r.status})"
        lines.append(f"  {i}. {r.subtask}\n     -> {ans}")
    lines.append("")
    lines.append(_render_answer(outcome.final_answer, "ok", outcome.steps_used, None, None))
    return "\n".join(lines)


def _render_answer(fa: FinalAnswer | None, status, steps, trace_path, message) -> str:
    if fa is None:
        return f"[{status}] {message or 'no answer'}"
    lines = [f"\n=== ANSWER ({status}, {steps} steps) ===", fa.summary]
    if fa.findings:
        lines.append("\nFindings:")
        lines += [f"  - {f.insight}: {f.evidence}" for f in fa.findings]
    if fa.caveats:
        lines.append("\nCaveats:")
        lines += [f"  - {c}" for c in fa.caveats]
    if trace_path:
        lines.append(f"\nTrace: {trace_path}")
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)
    settings = get_settings(model=args.model, temperature=args.temperature)
    setup_logging(settings.log_level if not args.stream else "WARNING")

    try:
        df = pd.read_csv(args.csv)
    except (FileNotFoundError, pd.errors.ParserError) as exc:
        print(f"Could not read CSV '{args.csv}': {exc}", file=sys.stderr)
        return 2
    if df.empty:
        print("The CSV has no rows to analyze.", file=sys.stderr)
        return 2

    if not args.query:
        print("--query is required.", file=sys.stderr)
        return 2

    llm = LLMClient(settings)
    on_event, on_token = make_stream_callbacks(args.stream)

    # Cross-session memory: load prior turns for this session.
    store = recap = None
    if args.session:
        store = SessionStore(settings.memory_dir)
        recap = SessionStore.recap(store.load(args.session))

    answer_summary = None
    if args.multi_agent:
        orch = Orchestrator(settings, llm, df)
        outcome = orch.run(args.query, on_event=on_event)
        print(render_orchestration(outcome))
        answer_summary = outcome.final_answer.summary
        rc = 0
    else:
        handler = None if args.non_interactive else interactive_clarify
        loop = AgentLoop(settings, llm, df, clarify_handler=handler)
        outcome = loop.run(args.query, history_recap=recap,
                           on_event=on_event, on_token=on_token)
        print(render_outcome(outcome))
        if outcome.final_answer:
            answer_summary = outcome.final_answer.summary
        rc = 0 if outcome.status in ("ok", "clarify") else 1

    # Persist this turn for next session.
    if store and answer_summary:
        store.append(args.session, args.query, answer_summary)

    return rc


if __name__ == "__main__":
    raise SystemExit(main())
