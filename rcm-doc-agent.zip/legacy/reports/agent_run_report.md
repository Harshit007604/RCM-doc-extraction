# Agent Run Report — CSV Data-Analysis Assistant

All traces and evaluation output below are **real** — produced by running the
code in this repo against `data/sample_sales.csv` (60 rows × 9 columns) with the
offline `mock` provider (`python src/evaluate.py`, `python src/agent.py`).

---

## 1. Architecture

The loop is a **LangGraph `StateGraph`** (`src/graph.py`). Nodes are the boxes;
conditional edges route on the decided action and on budgets:

```
                    +-----------------------------+
   CSV + question   |            decide           |<---------------------+
        |           | (LLM -> AgentStep JSON,     |                      |
        v           |  self-corrects bad JSON)    |                      |
  [profile df] ---> +--------------+--------------+                      |
                                   |  route on action / budget           |
             +----------+----------+----------+-----------+              |
             v          v                     v           v              |
         clarify     execute               finalize    give_up           |
             |     [AST guard ->               |           |             |
             |      sandbox + timeout]         v           v             |
             |          |  observation        END         END            |
             +----------+---------------------> (loop back to decide) ----+
```

Nodes: `decide`, `execute`, `clarify`, `finalize`, `give_up`. The agent's every
turn is a Pydantic-validated `AgentStep` (`clarify | execute | finalize`).
`execute` is the single tool: pandas code statically vetted then run in an
isolated subprocess with a hard timeout; its result is fed back as an
`OBSERVATION`, and `finalize` must cite evidence values from those observations.

> Engine note: LangGraph is the active engine. The earlier hand-rolled control
> loop is preserved (commented, not deleted) in `src/loop.py`, which now
> re-exports the graph engine as `AgentLoop` so all call sites are unchanged.
> Budgets (max_steps, max_code_retries) are enforced in the routers, with the
> graph's `recursion_limit` as a hard backstop.

---

## 2. Sample agent trace (full run)

**Query:** *"Which region has the highest total revenue?"*
**Provider:** `mock` · **Steps:** 2

Console:

```
step 1 | execute     | Detected intent 'top_region'; running a pandas snippet.
step 1 | observation | ok=True | {'region': 'South', 'revenue': 114350.35}
step 2 | finalize    | Observation received; grounding the answer in the value.
step 2 | FINAL       | South has the highest total revenue at 114350.35.
```

Machine-readable trace (`logs/run_<id>.jsonl`, verbatim):

```json
{"step": 1, "kind": "decision", "action": "execute",
 "thought": "Detected intent 'top_region'; running a pandas snippet.",
 "code": "s = df.groupby(\"region\")[\"revenue\"].sum()\nresult = {\"region\": s.idxmax(), \"revenue\": round(float(s.max()), 2)}"}
{"step": 1, "kind": "observation", "ok": true,
 "result_repr": "{'region': 'South', 'revenue': 114350.35}", "error": null, "duration_s": 0.427}
{"step": 2, "kind": "decision", "action": "finalize",
 "thought": "Observation received; grounding the answer in the computed value."}
{"step": 2, "kind": "final", "summary": "South has the highest total revenue at 114350.35."}
```

Final output:

```
=== ANSWER (ok, 2 steps) ===
South has the highest total revenue at 114350.35.

Findings:
  - Top region by revenue is South: 114350.35
```

This shows the full chain: **reason** (thought) → **act** (tool call with code)
→ **observe** (execution result) → **respond** (grounded final answer).

---

## 3. Robustness — guard-rails firing (real output)

Direct exercise of `src/sandbox.py`:

```
legit code            : ok=True   result=358
blocked import (os)   : ok=False  err=guard-rail: import of 'os' is not allowed
dunder escape attempt : ok=False  err=guard-rail: access to dunder attribute '__bases__' is not allowed
runtime error (bad col): ok=False err=KeyError: 'nope'
infinite loop         : ok=False  err=timeout after 2s
```

- Static AST guard blocks disallowed imports and dunder access **before**
  execution.
- Runtime errors are captured and returned as observations, so the loop can
  self-correct (bounded by `MAX_CODE_RETRIES`).
- A runaway loop is killed by the subprocess wall-clock timeout.
- LLM transient failures retry with exponential backoff; total failure returns a
  graceful `error`/`incomplete` outcome instead of crashing.

---

## 4. Evaluation results

`python src/evaluate.py --scenarios tests/scenarios.json` (provider `mock`):

| # | Scenario | Query | Expected | Result |
|---|----------|-------|----------|--------|
| 1 | dataset_shape | rows & columns? | finalize; "60 rows", "9 columns" | ✅ PASS |
| 2 | total_revenue | total revenue? | finalize; ≈ 307156.79 (±0.5) | ✅ PASS |
| 3 | top_region_by_revenue | highest-revenue region? | finalize; "South" | ✅ PASS |
| 4 | avg_revenue_by_category | avg revenue by category? | finalize; all 4 categories | ✅ PASS |
| 5 | ambiguous_request | "show me the interesting stuff" | **clarify** | ✅ PASS |

```
RESULT: 5/5 scenarios passed (100%)
```

Scenario 5 confirms the agent asks for clarification instead of guessing when no
metric or dimension can be inferred:

```
[5/5] ambiguous_request  ->  PASS
      - action==clarify: PASS (got clarify)
```

Checks are a mix of **qualitative** (action taken, required substrings present)
and **quantitative** (numeric answer within tolerance of ground truth computed
directly from the CSV).

---

## 5. Design decisions & trade-offs

- **JSON `AgentStep` control loop vs provider tool-calling.** Chose a
  Pydantic-validated JSON decision each turn. Cost: we parse/validate ourselves
  (with self-correction on bad JSON). Benefit: one identical loop across
  Anthropic/OpenAI/mock, fully inspectable and unit-testable, and an offline
  deterministic mode.
- **One general `run_python` tool vs many narrow tools.** A single guarded code
  tool covers arbitrary tabular questions and keeps every answer computation-
  backed. Cost: needs a real sandbox — handled with AST guard + process
  isolation + timeout.
- **Subprocess + pickle isolation.** Simple, correct, and gives a real
  kill-based timeout. Cost: per-call pickle overhead; fine for the target data
  sizes, replaceable with a persistent worker for large frames.
- **Grounding rule.** `finalize` must carry `evidence` values sourced from
  observations; the prompt bans citing un-observed numbers. This is the primary
  hallucination guard for a stats-heavy domain.
- **LiteLLM over per-provider SDKs.** A single gateway backend replaced the
  separate Anthropic/OpenAI clients. Cost: one more dependency and errors arrive
  as LiteLLM exception types (mapped to our transient/fatal split). Benefit: the
  provider becomes config (`MODEL=groq/...`), free tiers and local Ollama work
  without touching code, and retry/timeout logic lives in exactly one place.
- **Advanced technique = self-critique/self-correction.** Two independent
  correction loops (invalid-JSON re-emit; code-error retry with the error fed
  back) plus chain-of-thought in `thought`, rather than a heavier multi-agent
  setup that would add latency without clear benefit at this scope.

## 6. Additional capabilities (all implemented & verified)
Every item below runs offline under the `mock` provider.

**Multi-agent orchestration** — `--multi-agent`. Planner decomposed one request
into 4 subtasks, each answered by a fresh specialist loop, then synthesized:

```
=== MULTI-AGENT PLAN (4 subtasks) ===
  1. How many rows and columns does the dataset have?
     -> The dataset has 60 rows and 9 columns.
  2. What is the total revenue across all orders?
     -> Total revenue across all orders is 307156.79.
  3. Which region has the highest total revenue?
     -> South has the highest total revenue at 114350.35.
  4. What is the average revenue per order by category?
     -> Average revenue per order by category — Accessories: 4128.18, Laptops: 6117.48,
        Monitors: 4365.97, Peripherals: 6146.59.
=== ANSWER (ok, 8 steps) === Consolidated overview: ...
```

**Cross-session memory** — `--session <id>`. Two separate process runs share a
session file; the second run loads a recap of the first. `memory/demo.json`:

```json
[
  {"question": "Which region has the highest total revenue?",
   "answer": "South has the highest total revenue at 114350.35."},
  {"question": "What is the total revenue across all orders?",
   "answer": "Total revenue across all orders is 307156.79."}
]
```

**Streaming** — `--stream`. Tokens and step events stream live to stderr as the
agent works (`on_token` in `llm.py`, `on_event` in `loop.py`).

**Containerization** — `Dockerfile` + `docker-compose.yml` (`eval` and `ui`
services). **UI** — `ui/streamlit_app.py` (Streamlit) with live streaming, a
multi-agent toggle, CSV upload, and session memory.
