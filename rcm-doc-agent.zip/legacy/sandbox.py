"""Sandboxed execution of LLM-generated pandas code.

Two layers of defense:

1. Static AST guard (`static_guard`): reject code that imports disallowed
   modules, calls dangerous builtins, or touches dunder attributes used for
   sandbox escapes (`__globals__`, `__builtins__`, ...).
2. Process isolation: the vetted code runs in a *child process* with a
   restricted builtins namespace and a hard wall-clock timeout, so an infinite
   loop or a runaway allocation is bounded and killable.

This is a pragmatic sandbox suitable for a trusted-single-user tool, not a
hostile-multi-tenant boundary. Trade-offs are documented in the README.
"""

from __future__ import annotations

import ast
import os
import pickle
import subprocess
import sys
import tempfile
import time

import pandas as pd

from .schemas import ExecutionResult

# Modules the generated code may import. Everything else is rejected.
ALLOWED_IMPORTS = {"pandas", "numpy", "math", "statistics", "datetime"}

# Builtins/names that must never appear.
FORBIDDEN_CALLS = {
    "eval", "exec", "compile", "__import__", "open", "input",
    "globals", "locals", "vars", "getattr", "setattr", "delattr",
    "exit", "quit", "breakpoint", "memoryview",
}
FORBIDDEN_NAMES = {"os", "sys", "subprocess", "socket", "shutil", "pathlib", "requests"}

_RUNNER = os.path.join(os.path.dirname(__file__), "sandbox_runner.py")


class GuardRailError(ValueError):
    """Raised when static analysis rejects a snippet before execution."""


def static_guard(code: str) -> None:
    """Raise GuardRailError if the snippet is not safe to execute."""
    try:
        tree = ast.parse(code)
    except SyntaxError as exc:
        raise GuardRailError(f"SyntaxError: {exc}") from exc

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name.split(".")[0] not in ALLOWED_IMPORTS:
                    raise GuardRailError(f"import of '{alias.name}' is not allowed")
        elif isinstance(node, ast.ImportFrom):
            root = (node.module or "").split(".")[0]
            if root not in ALLOWED_IMPORTS:
                raise GuardRailError(f"import from '{node.module}' is not allowed")
        elif isinstance(node, ast.Attribute):
            if node.attr.startswith("__") and node.attr.endswith("__"):
                raise GuardRailError(f"access to dunder attribute '{node.attr}' is not allowed")
        elif isinstance(node, ast.Name):
            if node.id in FORBIDDEN_NAMES:
                raise GuardRailError(f"use of '{node.id}' is not allowed")
            if node.id in FORBIDDEN_CALLS:
                raise GuardRailError(f"use of '{node.id}' is not allowed")


def run_code(code: str, df: pd.DataFrame, timeout: float = 10.0) -> ExecutionResult:
    """Statically vet, then execute `code` against `df` in an isolated process."""
    start = time.perf_counter()

    try:
        static_guard(code)
    except GuardRailError as exc:
        return ExecutionResult(ok=False, error=f"guard-rail: {exc}",
                               duration_s=time.perf_counter() - start)

    with tempfile.TemporaryDirectory() as tmp:
        data_path = os.path.join(tmp, "df.pkl")
        code_path = os.path.join(tmp, "code.py")
        with open(data_path, "wb") as fh:
            pickle.dump(df, fh)
        with open(code_path, "w", encoding="utf-8") as fh:
            fh.write(code)

        try:
            proc = subprocess.run(
                [sys.executable, _RUNNER, "--data", data_path, "--code", code_path],
                capture_output=True, text=True, timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            return ExecutionResult(ok=False, error=f"timeout after {timeout}s",
                                   duration_s=time.perf_counter() - start)

        duration = time.perf_counter() - start
        if proc.returncode != 0 and not proc.stdout:
            return ExecutionResult(ok=False,
                                   error=f"runner crashed: {proc.stderr[:500]}",
                                   duration_s=duration)
        try:
            import json
            payload = json.loads(proc.stdout)
        except (ValueError, json.JSONDecodeError):
            return ExecutionResult(ok=False,
                                   error=f"unparseable runner output: {proc.stdout[:300]}",
                                   duration_s=duration)

        return ExecutionResult(
            ok=payload["ok"],
            stdout=payload.get("stdout", ""),
            result_repr=payload.get("result_repr", ""),
            error=payload.get("error"),
            duration_s=duration,
        )
