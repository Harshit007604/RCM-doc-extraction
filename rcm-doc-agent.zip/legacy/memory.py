"""Cross-session conversation persistence.

A minimal, dependency-free session store: each session is a JSON file under
`memory_dir` holding an append-only list of (question, answer) turns. Between
process runs, prior turns for a session are loaded and a compact recap is
injected into the prompt so the agent has continuity across sessions.
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass


@dataclass
class Turn:
    question: str
    answer: str


class SessionStore:
    def __init__(self, memory_dir: str):
        self.dir = memory_dir
        os.makedirs(self.dir, exist_ok=True)

    def _path(self, session_id: str) -> str:
        safe = "".join(c for c in session_id if c.isalnum() or c in ("-", "_")) or "default"
        return os.path.join(self.dir, f"{safe}.json")

    def load(self, session_id: str) -> list[Turn]:
        path = self._path(session_id)
        if not os.path.exists(path):
            return []
        with open(path, "r", encoding="utf-8") as fh:
            return [Turn(**t) for t in json.load(fh)]

    def append(self, session_id: str, question: str, answer: str) -> None:
        turns = self.load(session_id)
        turns.append(Turn(question=question, answer=answer))
        with open(self._path(session_id), "w", encoding="utf-8") as fh:
            json.dump([asdict(t) for t in turns], fh, indent=2)

    @staticmethod
    def recap(turns: list[Turn], max_turns: int = 5) -> str | None:
        """Compact, prompt-friendly recap of recent turns (or None if empty)."""
        if not turns:
            return None
        recent = turns[-max_turns:]
        return "\n".join(f"- Q: {t.question} | A: {t.answer}" for t in recent)
