r"""Multi-agent orchestration.

A planner agent decomposes a complex question into standalone subtasks, each
delegated to a fresh specialist `AgentLoop` (the same reason->act->observe loop),
and a synthesizer agent consolidates the sub-answers into one grounded answer.

    Planner ---> [subtask_1] -> Specialist -> answer_1 ---\
             |-> [subtask_2] -> Specialist -> answer_2 -----> Synthesizer -> final
             \-> [subtask_3] -> Specialist -> answer_3 ---/

Runs on the same LLMClient (including the offline mock), so it is fully
reproducible without credentials.
"""

from __future__ import annotations

import pandas as pd
from pydantic import ValidationError

from src.config import Settings
from src.llm import LLMClient, LLMError
from .loop import AgentLoop
from src.common import _extract_json
from .prompts import (
    PLANNER_SYSTEM_PROMPT,
    SYNTH_SYSTEM_PROMPT,
    build_planning_message,
    build_synthesis_message,
)
from .profiling import profile_dataframe, render_profile
from .schemas import FinalAnswer, OrchestrationOutcome, Plan, SubtaskResult


class Orchestrator:
    def __init__(self, settings: Settings, llm: LLMClient, df: pd.DataFrame):
        self.s = settings
        self.llm = llm
        self.df = df
        self.profile_text = render_profile(profile_dataframe(df))

    def run(self, question: str, on_event=None) -> OrchestrationOutcome:
        plan = self._plan(question)
        if on_event:
            on_event({"kind": "plan", "subtasks": plan.subtasks})

        results: list[SubtaskResult] = []
        steps = 0
        for i, subtask in enumerate(plan.subtasks, 1):
            if on_event:
                on_event({"kind": "delegate", "index": i, "subtask": subtask})
            # Fresh specialist per subtask; no clarify handler -> autonomous.
            worker = AgentLoop(self.s, self.llm, self.df, clarify_handler=None)
            outcome = worker.run(subtask, on_event=on_event)
            steps += outcome.steps_used
            results.append(SubtaskResult(subtask=subtask,
                                         answer=outcome.final_answer,
                                         status=outcome.status))

        final = self._synthesize(question, results)
        if on_event:
            on_event({"kind": "synthesis", "summary": final.summary})
        return OrchestrationOutcome(plan=plan, subtask_results=results,
                                    final_answer=final, steps_used=steps)

    # ------------------------------------------------------------------ #
    def _plan(self, question: str) -> Plan:
        msg = [{"role": "user",
                "content": build_planning_message(self.profile_text, question)}]
        raw = self.llm.complete(PLANNER_SYSTEM_PROMPT, msg)
        try:
            return Plan.model_validate_json(_extract_json(raw))
        except (ValidationError, ValueError):
            return Plan(reasoning="fallback: treat as a single subtask",
                        subtasks=[question])

    def _synthesize(self, question: str, results: list[SubtaskResult]) -> FinalAnswer:
        sub_answers = [
            (r.subtask, r.answer.summary if r.answer else f"({r.status})")
            for r in results
        ]
        # Single subtask that succeeded: no synthesis needed, reuse its answer.
        if len(results) == 1 and results[0].answer is not None:
            return results[0].answer

        msg = [{"role": "user", "content": build_synthesis_message(question, sub_answers)}]
        try:
            raw = self.llm.complete(SYNTH_SYSTEM_PROMPT, msg)
            return FinalAnswer.model_validate_json(_extract_json(raw))
        except (LLMError, ValidationError, ValueError):
            # Deterministic fallback: stitch the sub-answers.
            joined = " ".join(a for _, a in sub_answers)
            return FinalAnswer(summary=joined,
                               findings=[], caveats=["Synthesis fallback used."])
